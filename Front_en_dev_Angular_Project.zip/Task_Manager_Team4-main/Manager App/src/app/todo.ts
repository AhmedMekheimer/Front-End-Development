export class Todo{
    name:string;
    isCompleted:boolean;
}